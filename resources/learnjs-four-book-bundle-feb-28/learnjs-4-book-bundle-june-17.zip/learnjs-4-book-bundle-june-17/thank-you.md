# Hello, dear reader!

Thank you for buying the four-book bundle!

## You get these books:
- Learn.js #1: introduction to javascript
- Learn.js #2: making 2d games with node.js and browserify
- Learn.js #3: mapping with leaflet.js
- Development Environments for Beginners.

## June 17, 2014 update

It's been a while since this book has been updated, so here's a new chapter! This adds an introuduction to using the scripts field in a package.json file to create build scripts for your project.

## Changelog:

### v0.8.0 - June 17, 2014
- Add Introduction to npm scripts chapter
- Reorder chapters a little

Thanks,
Seth Vincent

http://learnjs.io
http://twitter.com/sethdvincent
http://twitter.com/learnjs_io
http://github.com/sethvincent

PS: If you haven't already, consider signing up for my email newsletter where I announce new books and other projects: http://eepurl.com/rN5Nv