# Hello, dear reader!

This release updates Making 2D Games with JavaScript to version 0.5.0.

## Changelog:

## v0.5.0 - June 12, 2014
- Add simple collision detection with aabb-2d chapter

I'm interested in hearing your thoughts, so please email me at hi@learnjs.io with any ideas or questions you have. 

Thanks again,
Seth Vincent

http://learnjs.io
http://superbigtree.com
http://twitter.com/sethdvincent
http://twitter.com/super_big_tree
http://github.com/sethvincent
