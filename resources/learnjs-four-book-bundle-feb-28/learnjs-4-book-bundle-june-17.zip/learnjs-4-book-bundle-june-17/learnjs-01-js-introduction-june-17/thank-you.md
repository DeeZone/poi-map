# Thank you!

Thank you so much for purchasing Learn.js #1: introduction to JavaScript and Node.js!

This book is the first in a series about building projects with javascript. Learn more at [learnjs.io](http://learnjs.io).

## June 17, 2014 update

It's been a while since this book has been updated, so here's a new chapter! This adds an introuduction to using the scripts field in a package.json file to create build scripts for your project.

Changelog:

## v0.8.0 - June 17, 2014
- Add Introduction to npm scripts chapter
- Reorder chapters a little

Thanks again for buying this book! And if you ever want to chat about JavaScript feel free to email me at hi@learnjs.io.


Seth Vincent
http://learnjs.io
http://twitter.com/sethdvincent
http://twitter.com/learnjs_io
http://github.com/sethvincent

PS: If you haven't already, consider signing up for my email newsletter where I announce new books and other projects: http://eepurl.com/rN5Nv