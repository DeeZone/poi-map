# Thank you!

Thank you so much for purchasing Learn.js #3: Mapping with Leaflet.js!

This book is the third in a series about building projects with javascript. Learn more at [learnjs.io](http://learnjs.io).

## This release includes a chapter about using alternate tile sources in your Leaflet maps!

If you haven't already seen it, I'm working on a book about making themes with Ghost. Learn more about it at http://themingwithghost.com or pre-order it for $15 at https://gumroad.com/l/theming-with-ghost. The first 4 chapters of Theming with Ghost are released on February 10, and the price goes up to $25 that day.

Here's the changelog for this release:

## v0.2.0 - February 3, 2014
- Add Using alternate tilesets chapter
- Make the "Basic elements of a Leaflet.js map" section its own chapter
- Many small typo fixes

Thanks again for buying this book! And if you ever want to chat about JavaScript feel free to email me at hi@learnjs.io.


Seth Vincent
http://learnjs.io
http://superbigtree.com
http://twitter.com/sethdvincent
http://twitter.com/super_big_tree
http://github.com/sethvincent

PS: If you haven't already, consider signing up for my email newsletter where I announce new books and other projects: http://eepurl.com/rN5Nv