# Thank you!

Thank you so much for purchasing Learn.js #1: introduction to JavaScript and Node.js!

This book is the first in a series about building projects with javascript. Learn more at [learnjs.io](http://learnjs.io).

## This release includes the start to an example apps section and a bunch of fixes!

If you haven't already seen it, I'm working on a book about making themes with Ghost. Learn more about it at http://themingwithghost.com or pre-order it for $15 at https://gumroad.com/l/theming-with-ghost. The first 4 chapters of Theming with Ghost are released on February 10, and the price goes up to $25 that day.

Here's the changelog for this release:

## v0.7.0 - February 3, 2014
- Start Part 3: examples
  - Add Using Backbone & jQuery with Browserify chapter
- Refactor chapters to make more sense.
- Many small typo fixes and improved explanations.

Thanks again for buying this book! And if you ever want to chat about JavaScript feel free to email me at hi@learnjs.io.


Seth Vincent
http://learnjs.io
http://superbigtree.com
http://twitter.com/sethdvincent
http://twitter.com/super_big_tree
http://github.com/sethvincent

PS: If you haven't already, consider signing up for my email newsletter where I announce new books and other projects: http://eepurl.com/rN5Nv