# Thank you!

Thank you so much for purchasing Learn.js #3: Mapping with Leaflet.js!

This book is the third in a series about building projects with javascript. Learn more at [learnjs.io](http://learnjs.io).

Here's the changelog for this release:

## v0.2.2 - May 27, 2014
- Add to leaflet-draw chapter to include instructions for saving data to a database

Thanks again for buying this book! And if you ever want to chat about JavaScript feel free to email me at hi@learnjs.io.


Seth Vincent
http://learnjs.io
http://superbigtree.com
http://twitter.com/sethdvincent
http://twitter.com/super_big_tree
http://github.com/sethvincent

PS: If you haven't already, consider signing up for my email newsletter where I announce new books and other projects: http://eepurl.com/rN5Nv