# Thank you!

Thank you so much for purchasing Development Environments for Beginners!

This book serves as an introduction to setting up development environments. Learn more about our other books at [learnjs.io](http://learnjs.io).

Here's the changelog for this release:

## v0.4.2 – May 13, 2014
- typo fixes submitted by [Jason Li](http://www.hongkonggong.com)
- fixes from [suisea](https://github.com/suisea)
- add instructions for viewing the site in the browser to ruby, js, python chapters
- improve vagrant instructions in ruby, js, python chapters

Thanks again for buying this book! And if you ever want to chat about JavaScript feel free to email me at hi@learnjs.io.

If you haven't already seen it, I recently launched http://subscribe.learnjs.io, where you can subscribe to all Learn.js books & screencasts for $12/month. Check it out!

Seth Vincent
http://learnjs.io
http://superbigtree.com
http://twitter.com/sethdvincent
http://twitter.com/super_big_tree
http://github.com/sethvincent

Thanks!
Seth Vincent

PS: If you haven't already, consider signing up for my email newsletter where I announce new books and other projects: http://eepurl.com/rN5Nv
